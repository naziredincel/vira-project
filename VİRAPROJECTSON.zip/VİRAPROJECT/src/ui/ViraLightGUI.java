package ui;

import dao.ReservationDAO;
import dao.VehicleDAO;
import dao.CustomerDAO;
import dao.model.Car;
import dao.model.Vehicle;
import dao.model.Customer;
import dao.model.Reservation;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class ViraLightGUI {

    //  DAO sınıflarını burada çağırıyoruz
    private static VehicleDAO vehicleDAO = new VehicleDAO();
    private static CustomerDAO customerDAO = new CustomerDAO();
    private static ReservationDAO reservationDAO = new ReservationDAO();

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Vira Araç Kiralama Sistemi");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 500);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(Color.WHITE);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(245, 245, 245));
        JLabel titleLabel = new JLabel("Vira Sistem Yönetimi");
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        headerPanel.add(titleLabel);
        frame.add(headerPanel, BorderLayout.NORTH);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(Color.WHITE);

        // Sekmeleri ekliyoruz 
        tabbedPane.addTab("Araçlar", createVehicleTab(frame));
        tabbedPane.addTab("Rezervasyonlar", createReservationTab(frame));
        tabbedPane.addTab("Müşteriler", createSimpleTab("Müşteri yönetimi ekranı yapım aşamasında..."));

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    
    private static JPanel createVehicleTab(JFrame parentFrame) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextArea textArea = new JTextArea("Araçları txt dosyasından çekmek için 'Listeyi Yenile' butonuna basın.");
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        textArea.setEditable(false);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);

        JButton btnAdd = new JButton("Yeni Araç Ekle");
        
        JButton btnRefresh = new JButton("Listeyi Yenile");

        // listeme kısmı
        btnRefresh.addActionListener(e -> {
            List<Vehicle> vehicles = vehicleDAO.loadAll(); // Txt dosyasından okur
            StringBuilder sb = new StringBuilder();
            sb.append("--- SİSTEMDEKİ ARAÇLAR ---\n\n");
            
            for(Vehicle v : vehicles) {
                sb.append("Plaka: ").append(v.getLicensePlate())
                  .append(" | ").append(v.getBrand()).append(" ").append(v.getModel())
                  .append(" | Fiyat: ").append(v.getBaseDailyPrice()).append(" TL\n");
            }
            textArea.setText(sb.toString()); // Ekrana gerçek veriyi basar
        });

        // EKLE BUTONU 
        btnAdd.addActionListener(e -> {
            openAddVehicleDialog(parentFrame, textArea);
        });

        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnAdd);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    // EKLE KAYDET İŞEMLERİ
    private static void openAddVehicleDialog(JFrame parentFrame, JTextArea textArea) {
        JDialog dialog = new JDialog(parentFrame, "Yeni Araç Ekle", true);
        dialog.setSize(350, 250);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new GridLayout(5, 2, 10, 10));

        JTextField txtBrand = new JTextField();
        JTextField txtModel = new JTextField();
        JTextField txtPlate = new JTextField();
        JTextField txtPrice = new JTextField();

        dialog.add(new JLabel("Marka:")); dialog.add(txtBrand);
        dialog.add(new JLabel("Model:")); dialog.add(txtModel);
        dialog.add(new JLabel("Plaka:")); dialog.add(txtPlate);
        dialog.add(new JLabel("Günlük Fiyat:")); dialog.add(txtPrice);

        JButton btnSave = new JButton("Kaydet");
        
        // DOSYA YAZDIRMA
        btnSave.addActionListener(e -> {
            try {
                String brand = txtBrand.getText();
                String model = txtModel.getText();
                String plate = txtPlate.getText();
                double price = Double.parseDouble(txtPrice.getText());

                // NESNE ÜRETİMİ
                Vehicle newCar = new Car(brand, model, plate, price, 0, true);

                //  VehicleDAO SINIFINA DOSYA EKLEME
                vehicleDAO.add(newCar);
                
                JOptionPane.showMessageDialog(dialog, "Araç başarıyla txt dosyasına eklendi!");
                dialog.dispose(); // Formu kapat

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Hata oluştu! Lütfen fiyata sayı girin.", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(new JLabel("")); 
        dialog.add(btnSave);
        dialog.setVisible(true);
    }

    // REZERVASYON SEKMESİ
    private static JPanel createReservationTab(JFrame parentFrame) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextArea textArea = new JTextArea("Rezervasyonları görmek için 'Listeyi Yenile' butonuna basın.");
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        textArea.setEditable(false);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);

        JButton btnAdd = new JButton("Yeni Rezervasyon Oluştur");
        JButton btnRefresh = new JButton("Listeyi Yenile");

        btnRefresh.addActionListener(e -> {
            List<Reservation> reservations = reservationDAO.loadAll(vehicleDAO, customerDAO);
            StringBuilder sb = new StringBuilder("--- MEVCUT REZERVASYONLAR ---\n\n");
            for(Reservation r : reservations) {
                sb.append(r.toString()).append("\n");
            }
            textArea.setText(sb.toString());
        });

        btnAdd.addActionListener(e -> {
            openAddReservationDialog(parentFrame, textArea);
        });

        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnAdd);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private static void openAddReservationDialog(JFrame parentFrame, JTextArea textArea) {
        List<Vehicle> vehicles = vehicleDAO.loadAll();
        List<Customer> customers = customerDAO.loadAll();

        if (vehicles.isEmpty() || customers.isEmpty()) {
            JOptionPane.showMessageDialog(parentFrame, 
                "Rezervasyon yapabilmek için sistemde en az 1 Araç ve 1 Müşteri kayıtlı olmalıdır!\n(customers.txt dosyasına elle müşteri ekleyebilirsiniz)", 
                "Eksik Veri", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog(parentFrame, "Rezervasyon Oluştur", true);
        dialog.setSize(450, 300);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setLayout(new GridLayout(5, 2, 10, 10));

        JComboBox<Vehicle> cmbVehicle = new JComboBox<>(vehicles.toArray(new Vehicle[0]));
        JComboBox<Customer> cmbCustomer = new JComboBox<>(customers.toArray(new Customer[0]));
        JTextField txtStartDate = new JTextField(LocalDate.now().toString()); 
        JTextField txtEndDate = new JTextField(LocalDate.now().plusDays(3).toString()); 

        dialog.add(new JLabel("Araç Seçin:")); dialog.add(cmbVehicle);
        dialog.add(new JLabel("Müşteri Seçin:")); dialog.add(cmbCustomer);
        dialog.add(new JLabel("Başlangıç (YYYY-AA-GG):")); dialog.add(txtStartDate);
        dialog.add(new JLabel("Bitiş (YYYY-AA-GG):")); dialog.add(txtEndDate);

        JButton btnSave = new JButton("Rezervasyonu Tamamla");
        
        btnSave.addActionListener(e -> {
            try {
                Vehicle selectedVehicle = (Vehicle) cmbVehicle.getSelectedItem();
                Customer selectedCustomer = (Customer) cmbCustomer.getSelectedItem();
                LocalDate start = LocalDate.parse(txtStartDate.getText());
                LocalDate end = LocalDate.parse(txtEndDate.getText());

                if (start.isAfter(end) || start.isEqual(end)) {
                    JOptionPane.showMessageDialog(dialog, "Bitiş tarihi başlangıçtan sonra olmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                List<Reservation> existingReservations = reservationDAO.loadAll(vehicleDAO, customerDAO);
                for(Reservation r : existingReservations) {
                    if(r.getVehicle().getVehicleId().equals(selectedVehicle.getVehicleId())) {
                        if(r.isConflict(start, end)) {
                            JOptionPane.showMessageDialog(dialog, 
                                "DİKKAT: Seçilen araç bu tarihler arasında zaten rezerve edilmiş!\nLütfen başka bir tarih veya araç seçin.", 
                                "Çakışma Tespit Edildi", JOptionPane.ERROR_MESSAGE);
                            return; 
                        }
                    }
                }

                Reservation newRes = new Reservation(selectedVehicle, selectedCustomer, start, end);
                reservationDAO.add(newRes);
                
                JOptionPane.showMessageDialog(dialog, "Rezervasyon başarıyla oluşturuldu!\nToplam Tutar: " + newRes.getTotalCost() + " TL");
                dialog.dispose();

            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(dialog, "Tarih formatı hatalı! (Örn: 2026-05-15 şeklinde girin)", "Hata", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Beklenmeyen bir hata oluştu: " + ex.getMessage(), "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(new JLabel("")); 
        dialog.add(btnSave);
        dialog.setVisible(true);
    }

    // DİĞER SEKMELER İÇİN YARDIMCI METOT
    private static JPanel createSimpleTab(String message) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.add(new JLabel(message));
        return panel;
    }
}
